<?php
/*
Plugin Name: DAO Wallet Creator
Description: Crea wallets de autocustodia para usuarios registrados y permite acceso a una DAO en Aragon.
Version: 1.0
Author: Danako
*/

add_shortcode('dao_wallet_panel', 'dao_wallet_panel_shortcode');

function dao_wallet_panel_shortcode() {
    ob_start(); ?>

    <div id="wallet-section" style="max-width:600px;margin:20px auto;padding:20px;border:1px solid #ccc;border-radius:8px;">
        <h3>Tu Wallet Polygon</h3>
        <p><strong>Dirección:</strong> <span id="wallet-address">[Generando...]</span></p>
        <button onclick="generateWallet()">Generar Wallet</button>
        <button onclick="downloadPrivateKey()">Descargar Clave Privada</button>
        <br><br>
        <a href="https://app.aragon.org/#/tu-dao.eth" target="_blank">
            <button>Ir a la DAO</button>
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.min.js"></script>
    <script>
        const encrypt = (data) => btoa(unescape(encodeURIComponent(data)));
        const decrypt = (data) => decodeURIComponent(escape(atob(data)));

        function generateWallet() {
            const wallet = ethers.Wallet.createRandom();
            const privateKey = wallet.privateKey;
            const address = wallet.address;

            localStorage.setItem('dao_wallet_private_key', encrypt(privateKey));
            localStorage.setItem('dao_wallet_address', address);

            document.getElementById("wallet-address").textContent = address;

            alert("¡Wallet generada! Guarda tu clave privada.");
        }

        function downloadPrivateKey() {
            const encrypted = localStorage.getItem('dao_wallet_private_key');
            if (!encrypted) {
                alert("Primero genera una wallet.");
                return;
            }

            const privateKey = decrypt(encrypted);
            const blob = new Blob([privateKey], { type: "text/plain;charset=utf-8" });
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = "clave_privada_polygon.txt";
            link.click();
        }

        document.addEventListener("DOMContentLoaded", function () {
            const address = localStorage.getItem('dao_wallet_address');
            if (address) {
                document.getElementById("wallet-address").textContent = address;
            }
        });
    </script>

    <?php return ob_get_clean();
}
